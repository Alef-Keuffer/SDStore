var searchData=
[
  ['next_5fpos_0',['next_pos',['../server_8c.html#acfa9669af12108fe2022d8bcf78a2284',1,'server.c']]]
];
