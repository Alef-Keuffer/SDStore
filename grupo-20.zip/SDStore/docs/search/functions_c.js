var searchData=
[
  ['task_5fis_5fpossible_0',['task_is_possible',['../server_8c.html#a42f0738792d5bd6a6894829ef136a2ed',1,'server.c']]],
  ['test1_1',['test1',['../main_8c.html#a9812bf7db5ce0570bded9ceefeea0ebf',1,'main.c']]]
];
