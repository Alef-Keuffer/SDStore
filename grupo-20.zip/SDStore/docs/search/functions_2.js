var searchData=
[
  ['exec_0',['exec',['../server_8c.html#a2e807e730ac27f236eed2cab9b086eb6',1,'server.c']]]
];
