var searchData=
[
  ['global_5fmax_5fparallel_5ftasks_0',['GLOBAL_MAX_PARALLEL_TASKS',['../server_8c.html#a06fc87d81c62e9abb8790b6e5713c55baa544e9e3962fc6548cfe6430abf8c035',1,'server.c']]]
];
