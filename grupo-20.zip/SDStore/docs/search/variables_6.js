var searchData=
[
  ['max_5fparallel_5ftask_0',['max_parallel_task',['../server_8c.html#a3d6f28e1f7e648d87f77bb3c1a685c8f',1,'server.c']]],
  ['monitor_1',['monitor',['../structtask__t.html#aaa4486434f64825f1e25a27c9c290f25',1,'task_t']]]
];
