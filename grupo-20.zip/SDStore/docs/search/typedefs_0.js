var searchData=
[
  ['task_5ft_0',['task_t',['../__server_8h.html#a989e278a815d7ada960572a3e9fad896',1,'_server.h']]]
];
