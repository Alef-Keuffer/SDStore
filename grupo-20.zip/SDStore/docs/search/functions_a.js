var searchData=
[
  ['queue_5fis_5fempty_0',['queue_is_empty',['../server_8c.html#a52b1686f8b94e5c077974007903b5ad2',1,'server.c']]]
];
