var searchData=
[
  ['task_5ft_0',['task_t',['../structtask__t.html',1,'']]]
];
