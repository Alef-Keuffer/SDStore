var searchData=
[
  ['ops_0',['ops',['../structtask__t.html#a6a9ff090520b6e06d0b58ee828d8fa65',1,'task_t']]],
  ['ops_5ftotals_1',['ops_totals',['../structtask__t.html#a917aaaed63fddb2bc840ab5730cfbcad',1,'task_t']]]
];
