var client_8c =
[
    [ "delimcat", "client_8c.html#a0163c1b682279c0ecf5bc612f622664b", null ],
    [ "main", "client_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "sig_handler", "client_8c.html#a30215074a82a05896a51d872abcd854e", null ],
    [ "FIFO", "client_8c.html#af5bdd3256d52564bdbd9dd04845a09f3", null ]
];