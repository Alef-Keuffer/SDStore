var searchData=
[
  ['server_2ec_0',['server.c',['../server_8c.html',1,'']]],
  ['server_5ffifo_5frd_1',['server_fifo_rd',['../server_8c.html#a871c3c797e87eb2a63adad0dbb4c891c',1,'server.c']]],
  ['server_5ffifo_5fwr_2',['server_fifo_wr',['../server_8c.html#a1080255dd670ac491590c0ef2095b1b9',1,'server.c']]],
  ['sig_5fchild_3',['sig_child',['../server_8c.html#adfbfb17e1bad491fec2ba2237c045942',1,'server.c']]],
  ['sig_5fhandler_4',['sig_handler',['../client_8c.html#a30215074a82a05896a51d872abcd854e',1,'sig_handler(__attribute__((unused)) int signum):&#160;client.c'],['../server_8c.html#a10a0633a37d64a974528026a0bb068f3',1,'sig_handler(__attribute__((unused)) int signum):&#160;server.c']]],
  ['src_5',['src',['../structtask__t.html#a48e45bf91374e3b08a6e9e9953e89c70',1,'task_t']]]
];
