var searchData=
[
  ['pos_0',['pos',['../structtask__t.html#a8e950da09d345754898599115ae05e8d',1,'task_t']]],
  ['pri_1',['pri',['../structtask__t.html#aa598bac9471cf89410bcbc3113933a9b',1,'task_t']]]
];
