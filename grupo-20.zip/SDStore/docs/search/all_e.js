var searchData=
[
  ['pipe_5fprogs_0',['pipe_progs',['../server_8c.html#a9b23d98843e86c5595cb9e8167921eda',1,'server.c']]],
  ['pos_1',['pos',['../structtask__t.html#a8e950da09d345754898599115ae05e8d',1,'task_t']]],
  ['pri_2',['pri',['../structtask__t.html#aa598bac9471cf89410bcbc3113933a9b',1,'task_t']]],
  ['process_5fmessage_3',['process_message',['../server_8c.html#ae3d717e33675b6c5f82c0407bd1e1104',1,'server.c']]]
];
