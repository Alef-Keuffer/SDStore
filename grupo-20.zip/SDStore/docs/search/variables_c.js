var searchData=
[
  ['transformations_5ffolder_0',['TRANSFORMATIONS_FOLDER',['../server_8c.html#a55e18a680ca26e638893e218af0d98dd',1,'server.c']]]
];
