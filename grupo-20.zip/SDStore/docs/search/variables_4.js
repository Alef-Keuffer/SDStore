var searchData=
[
  ['g_0',['g',['../server_8c.html#a0aad49e49dbd24aaaf42bcfee131fe95',1,'server.c']]],
  ['get_5ftransformation_5factive_5fcount_1',['get_transformation_active_count',['../server_8c.html#a86a0901f8bfb7d33939e03224d170b98',1,'server.c']]],
  ['get_5ftransformation_5factive_5flimit_2',['get_transformation_active_limit',['../server_8c.html#a62e2473cea8d8658781b46db0ce225c7',1,'server.c']]]
];
