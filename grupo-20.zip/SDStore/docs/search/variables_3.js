var searchData=
[
  ['fifo_0',['FIFO',['../client_8c.html#af5bdd3256d52564bdbd9dd04845a09f3',1,'client.c']]]
];
