var searchData=
[
  ['pipe_5fprogs_0',['pipe_progs',['../server_8c.html#a9b23d98843e86c5595cb9e8167921eda',1,'server.c']]],
  ['process_5fmessage_1',['process_message',['../server_8c.html#ae3d717e33675b6c5f82c0407bd1e1104',1,'server.c']]]
];
