var searchData=
[
  ['sig_5fchild_0',['sig_child',['../server_8c.html#adfbfb17e1bad491fec2ba2237c045942',1,'server.c']]],
  ['sig_5fhandler_1',['sig_handler',['../client_8c.html#a30215074a82a05896a51d872abcd854e',1,'sig_handler(__attribute__((unused)) int signum):&#160;client.c'],['../server_8c.html#a10a0633a37d64a974528026a0bb068f3',1,'sig_handler(__attribute__((unused)) int signum):&#160;server.c']]]
];
