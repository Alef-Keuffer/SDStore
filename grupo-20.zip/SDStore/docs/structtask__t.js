var structtask__t =
[
    [ "client_pid_str", "structtask__t.html#ad7ff6b93d2530df5d5b388cf7c5e192c", null ],
    [ "dst", "structtask__t.html#a8373adc3a1f38c97610f5243b74137c0", null ],
    [ "monitor", "structtask__t.html#aaa4486434f64825f1e25a27c9c290f25", null ],
    [ "num_ops", "structtask__t.html#a94303b5d5e50924b3a92c0ef658c071d", null ],
    [ "ops", "structtask__t.html#a6a9ff090520b6e06d0b58ee828d8fa65", null ],
    [ "ops_totals", "structtask__t.html#a917aaaed63fddb2bc840ab5730cfbcad", null ],
    [ "pos", "structtask__t.html#a8e950da09d345754898599115ae05e8d", null ],
    [ "pri", "structtask__t.html#aa598bac9471cf89410bcbc3113933a9b", null ],
    [ "src", "structtask__t.html#a48e45bf91374e3b08a6e9e9953e89c70", null ]
];