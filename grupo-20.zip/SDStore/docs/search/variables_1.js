var searchData=
[
  ['client_5fpid_5fstr_0',['client_pid_str',['../structtask__t.html#ad7ff6b93d2530df5d5b388cf7c5e192c',1,'task_t']]]
];
