var searchData=
[
  ['server_5ffifo_5frd_0',['server_fifo_rd',['../server_8c.html#a871c3c797e87eb2a63adad0dbb4c891c',1,'server.c']]],
  ['server_5ffifo_5fwr_1',['server_fifo_wr',['../server_8c.html#a1080255dd670ac491590c0ef2095b1b9',1,'server.c']]],
  ['src_2',['src',['../structtask__t.html#a48e45bf91374e3b08a6e9e9953e89c70',1,'task_t']]]
];
