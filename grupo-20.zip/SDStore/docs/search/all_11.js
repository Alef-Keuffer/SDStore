var searchData=
[
  ['task_5fis_5fpossible_0',['task_is_possible',['../server_8c.html#a42f0738792d5bd6a6894829ef136a2ed',1,'server.c']]],
  ['task_5ft_1',['task_t',['../structtask__t.html',1,'task_t'],['../__server_8h.html#a989e278a815d7ada960572a3e9fad896',1,'task_t():&#160;_server.h']]],
  ['test1_2',['test1',['../main_8c.html#a9812bf7db5ce0570bded9ceefeea0ebf',1,'main.c']]],
  ['transformations_5ffolder_3',['TRANSFORMATIONS_FOLDER',['../server_8c.html#a55e18a680ca26e638893e218af0d98dd',1,'server.c']]]
];
