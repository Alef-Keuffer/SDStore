var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "_server.h", "__server_8h.html", "__server_8h" ],
    [ "client.c", "client_8c.html", "client_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "server.c", "server_8c.html", "server_8c" ]
];