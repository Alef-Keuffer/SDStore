var searchData=
[
  ['active_5ftasks_0',['active_tasks',['../server_8c.html#ab8d8d82827a03a7cffe064c5a31042f1',1,'server.c']]]
];
