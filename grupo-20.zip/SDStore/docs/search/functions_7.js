var searchData=
[
  ['main_0',['main',['../client_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;client.c'],['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.c'],['../server_8c.html#a1bc81224f51eef1f0cceae3d97bf9805',1,'main(__attribute__((unused)) int argc, char *argv[]):&#160;server.c']]],
  ['monitor_5frun_5ftask_1',['monitor_run_task',['../server_8c.html#a5140edc105e02941900368035de97bc4',1,'server.c']]]
];
