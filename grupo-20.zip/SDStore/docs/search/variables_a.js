var searchData=
[
  ['queue_0',['queue',['../server_8c.html#a0cb553e7fd7203d776cb6bffe885dbf2',1,'server.c']]]
];
