var __server_8h =
[
    [ "task_t", "structtask__t.html", "structtask__t" ],
    [ "task_t", "__server_8h.html#a989e278a815d7ada960572a3e9fad896", null ]
];