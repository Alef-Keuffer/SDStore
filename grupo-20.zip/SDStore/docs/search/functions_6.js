var searchData=
[
  ['listening_5floop_0',['listening_loop',['../server_8c.html#a02c1f2005b74147f6b502f0790ac668f',1,'server.c']]]
];
