var searchData=
[
  ['g_0',['g',['../server_8c.html#a0aad49e49dbd24aaaf42bcfee131fe95',1,'server.c']]],
  ['get_5fstatus_5fstr_1',['get_status_str',['../server_8c.html#aa15f1ad63128e15e1ea0cdcb37713e70',1,'server.c']]],
  ['get_5ftransformation_5factive_5fcount_2',['get_transformation_active_count',['../server_8c.html#a86a0901f8bfb7d33939e03224d170b98',1,'server.c']]],
  ['get_5ftransformation_5factive_5flimit_3',['get_transformation_active_limit',['../server_8c.html#a62e2473cea8d8658781b46db0ce225c7',1,'server.c']]],
  ['global_5fmax_5fparallel_5ftasks_4',['GLOBAL_MAX_PARALLEL_TASKS',['../server_8c.html#a06fc87d81c62e9abb8790b6e5713c55baa544e9e3962fc6548cfe6430abf8c035',1,'server.c']]]
];
