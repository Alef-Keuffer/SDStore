var searchData=
[
  ['next_5fpos_0',['next_pos',['../server_8c.html#acfa9669af12108fe2022d8bcf78a2284',1,'server.c']]],
  ['num_5factive_5ftasks_1',['num_active_tasks',['../server_8c.html#a06605e8dde108d96cd043e0f5cd13f7a',1,'server.c']]],
  ['num_5fops_2',['num_ops',['../structtask__t.html#a94303b5d5e50924b3a92c0ef658c071d',1,'task_t']]]
];
