var searchData=
[
  ['decrement_5factive_5ftransformations_5fcount_0',['decrement_active_transformations_count',['../server_8c.html#aa02528b86361fdbbf110f64e33001545',1,'server.c']]],
  ['delimcat_1',['delimcat',['../client_8c.html#a0163c1b682279c0ecf5bc612f622664b',1,'client.c']]]
];
